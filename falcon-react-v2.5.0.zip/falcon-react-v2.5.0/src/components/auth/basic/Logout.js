import React from 'react';
import LogoutContent from '../LogoutContent';

const Logout = () => (
  <div className="text-center">
    <LogoutContent />
  </div>
);

export default Logout;
