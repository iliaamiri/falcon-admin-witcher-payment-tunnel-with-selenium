export default [
  'Select Category',
  'Health & Wellness',
  'Business & Professional',
  'Performing & Visual Arts',
  'Science & Technology',
  'Sports & Fitness',
  'Charity & Causes',
  'Film & Media',
  'Fashion & Beauty',
  'Travel & Outdoor',
  'Entertainment',
  'Other'
];
