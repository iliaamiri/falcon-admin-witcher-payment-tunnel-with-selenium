export default [{ value: 1, label: 'Concert' }, { value: 2, label: 'New Year' }, { value: 3, label: 'Party' }];
