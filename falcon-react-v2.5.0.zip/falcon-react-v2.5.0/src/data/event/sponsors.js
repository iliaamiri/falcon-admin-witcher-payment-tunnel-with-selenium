export default [
  { value: 1, label: 'Microsoft Corporation' },
  { value: 2, label: 'Technext Limited' },
  { value: 3, label: 'Hewlett-Packard' }
];
