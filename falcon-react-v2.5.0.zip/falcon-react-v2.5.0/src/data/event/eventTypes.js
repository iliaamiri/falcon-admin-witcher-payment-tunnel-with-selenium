export default [
  { value: 1, label: 'Class, Training, or Workshop' },
  { value: 2, label: 'Concert or Performance' },
  { value: 3, label: 'Conference' },
  { value: 4, label: 'Convention' },
  { value: 5, label: 'Dinner or Gala' },
  { value: 6, label: 'Festival or Fair' }
];
