export default [
  { value: 1, label: 'Massachusetts Institute of Technology' },
  { value: 2, label: 'University of Chicago' },
  { value: 3, label: 'GSAS Open Labs At Harvard' },
  { value: 4, label: 'California Institute of Technology' }
];
