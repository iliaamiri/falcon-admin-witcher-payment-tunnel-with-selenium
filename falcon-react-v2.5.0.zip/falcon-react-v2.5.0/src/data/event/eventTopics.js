export default [
  { value: 1, label: 'Auto, Boat &amp; Air' },
  { value: 2, label: 'Business &amp; Professional' },
  { value: 3, label: 'Charity &amp; Causes' },
  { value: 4, label: 'Community &amp; Culture' },
  { value: 5, label: 'Family &amp; Education' },
  { value: 7, label: 'Fashion &amp; Beauty' },
  { value: 8, label: 'Film, Media &amp; Entertainment' },
  { value: 9, label: 'Food &amp; Drink' },
  { value: 10, label: 'Government &amp; Politics' }
];
