export default [
  { name: 'Front desks', price: '0.00', checked: true },
  { name: 'Green gallery', price: '5.00' },
  { name: 'VIP', price: '20.00' }
];
