export default [
  {
    title: 'New components are ready to publish!',
    date: 'Jan 15',
    read: '8min'
  },
  {
    title: "January '19 New Features Newsletter",
    date: 'Jan 5',
    read: '3min',
    star: true
  },
  {
    title: 'Merry Christmas From the Falcon Team.',
    date: 'Dec 25',
    read: '2min'
  },
  {
    title: 'The New Falcon Theme',
    date: 'Dec 23',
    read: '10min'
  }
];
