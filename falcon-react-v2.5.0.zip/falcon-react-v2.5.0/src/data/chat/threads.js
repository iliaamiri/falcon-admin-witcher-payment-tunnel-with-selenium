export default [
  {
    id: 0,
    userId: 1,
    messagesId: 0,
    read: true
  },
  {
    id: 1,
    userId: [0],
    messagesId: 1,
    read: true
  },
  {
    id: 2,
    userId: 3,
    messagesId: 2,
    read: true
  },
  {
    id: 3,
    userId: 13,
    messagesId: 3,
    read: false
  },
  {
    id: 4,
    userId: 4,
    messagesId: 4,
    read: false
  },
  {
    id: 5,
    userId: 5,
    messagesId: 5,
    read: true
  },
  {
    id: 6,
    userId: 10,
    messagesId: 6,
    read: true
  },
  {
    id: 7,
    userId: 11,
    messagesId: 7,
    read: true
  },
  {
    id: 8,
    userId: 12,
    messagesId: 8,
    read: true
  },
  {
    id: 9,
    userId: 22,
    messagesId: 9,
    read: true
  },
  {
    id: 10,
    userId: 23,
    messagesId: 10,
    read: true
  }
];
