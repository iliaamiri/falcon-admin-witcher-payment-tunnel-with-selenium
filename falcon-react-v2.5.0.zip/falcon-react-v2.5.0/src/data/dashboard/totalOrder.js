export default [15000, 43400];
