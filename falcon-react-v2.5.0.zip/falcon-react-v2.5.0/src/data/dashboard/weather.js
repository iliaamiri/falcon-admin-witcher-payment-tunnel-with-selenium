export default {
  city: 'New York City',
  condition: 'Sunny',
  precipitation: '50%',
  temperature: 31,
  highestTemperature: 32,
  lowestTemperature: 25
};
