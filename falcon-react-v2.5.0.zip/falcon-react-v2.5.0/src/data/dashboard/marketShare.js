export default [
  { id: 1, value: 53000000, name: 'Samsung', color: '#2c7be5' },
  { id: 2, value: 19000000, name: 'Huawei', color: '#27bcfd' },
  { id: 3, value: 20000000, name: 'Apple', color: '#d8e2ef' }
];
