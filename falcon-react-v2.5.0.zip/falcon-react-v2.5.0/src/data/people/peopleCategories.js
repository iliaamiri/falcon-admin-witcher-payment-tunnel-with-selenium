export default [
  'All followers',
  'Concert Choir',
  'Clubchem',
  'Chamber Music Society',
  'Alpha Chi Omega',
  'Alpine Ski Club',
  'Career Club',
  'Musical Club',
  'Asymptones',
  'Clubchem',
  'Brain Trust',
  'Other'
];
