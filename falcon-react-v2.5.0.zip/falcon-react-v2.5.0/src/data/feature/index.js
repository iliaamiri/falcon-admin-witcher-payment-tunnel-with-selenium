import processList from './processList';
import serviceList from './serviceList';

export { processList, serviceList };
